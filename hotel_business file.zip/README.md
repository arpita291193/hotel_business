# Hotel Bookings — Insight Studio

A more narrative, visually rich Streamlit dashboard built on the same
119k-row hotel bookings dataset (177 Indonesian cities/regencies, two hotel
types). Unlike the first version, this one is organized around business
questions and includes geography, statistical testing, and a colorful,
animated interface with a mouse-tracking spotlight effect.

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

`hotel_bookings_data.csv` must sit alongside `app.py` (already included).

## What's inside

- **Hero + sidebar filters** — hotel type, year, market segment, booking
  status, lead-time range. Everything below reacts live.
- **Business Questions tab** — six concrete questions the dashboard is
  built to answer (revenue drivers, cancellation risk, who books, geographic
  concentration, seasonality, loyalty), plus a snapshot KPI row.
- **Demographics tab** — family composition, customer type, meal plan,
  party size, special requests.
- **Geography tab** — a bubble map centered on Indonesia (bubble size =
  bookings, color = cancellation rate) built from a hand-mapped
  city/regency → lat-lon lookup covering the top cities in the dataset,
  plus a concentration-risk view of how dependent the business is on
  Bali (Kota Denpasar) alone.
- **Bar · Pie · Donut tab** — market segment and channel bar charts, hotel
  type and deposit type pies, completed-vs-canceled and year-mix donuts.
- **KPIs & Trends tab** — six operational KPI cards (lead time, length of
  stay, special requests, parking demand, booking changes, waitlist days)
  and two trend charts: bookings vs average daily rate over time, and the
  cancellation-rate trend.
- **Technical Analysis tab** — a brief statistical read: Pearson
  correlations (lead time, ADR, and special requests vs cancellation), a
  Welch's t-test comparing lead time between canceled and completed
  bookings, the loyalty cancellation gap, ADR distribution shape (std
  dev, coefficient of variation, skew), a year-over-year volume read, and
  a full correlation heatmap across the numeric booking features.

## Visual details

- Animated multi-color gradient background (`.stApp`), glassmorphism cards
  throughout, and a "flashlight" radial-gradient spotlight that follows
  the mouse across the whole app (injected via a small script that reaches
  into the parent document — this is a best-effort browser trick, so
  behavior can vary slightly by deployment environment).
- All charts use Plotly's dark template with a consistent custom palette
  so they sit naturally on the colorful background.

## Notes on the data

- One negative ADR value and the top 0.1% ADR outliers are clipped/trimmed.
- Missing `children`, `city`, `agent`, `company` are filled rather than
  dropped, to preserve sample size.
- The geography map covers the ~40 highest-volume cities/regencies
  (about 97–98% of bookings); the long tail of smaller locations isn't
  individually geocoded and is excluded from the map only (not from any
  other chart or KPI).
